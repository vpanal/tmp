# Customlib - Collection of Python classes for working with network protocols.
#
# Copyright (C) 2023 Fortra. All rights reserved.
#
# This software is provided under a slightly modified version
# of the Apache Software License. See the accompanying LICENSE file
# for more information.
#

import pkg_resources
from customlib import __path__


try:
    version = pkg_resources.get_distribution('customlib').version
except pkg_resources.DistributionNotFound:
    version = "?"
    print("Cannot determine Customlib version. "
          "If running from source you should at least run \"python setup.py egg_info\"")
BANNER = "Customlib v{} - Copyright 2023 Fortra\n".format(version)
WARNING_BANNER = "".join(("===============================================================================\n",
                          "  Warning: This functionality will be deprecated in the next Customlib version  \n", 
                          "===============================================================================\n"))

def getInstallationPath():
    return 'Customlib Library Installation Path: {}'.format(__path__[0])
